#include "HelloWorldScene.h"
#include "time.h"
#include "stdlib.h"
#include <iostream>
USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }

    
    auto visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();
    
    widthLeft = origin.x;
    widthRight = origin.x + visibleSize.width;
    heightDown = origin.y;
    heightUp = origin.y + visibleSize.height;
    
    
    auto listener1 = EventListenerTouchOneByOne::create();
    listener1->onTouchBegan = [&](Touch* touch, Event* event){
        
        const unsigned int x = touch->getLocation().x,y = touch->getLocation().y;
        const int radius = random(1, 100);
        const int speedX = random(-10, 10),speedY = random(-10,10);
        
        DrawNode* tempball = DrawNode::create();
        tempball->drawDot(Vec2(0,0), radius, Color4F(1.0f,1.0f,1.0f,1.0f));
        tempball->setPosition(Vec2(x,y));
        this->addChild(tempball);
        
        Ball b(tempball,speedX,speedY,radius);
        this->balllist.push_back(b);

        
        return true;
    };
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener1, this);
    

    
    auto ref = [&](float dt) {
        
        if(!balllist.empty()){
            for(auto& ball:balllist){
                
                ball.ballObeject -> setPosition(ball.ballObeject->getPositionX() + ball.speedX, ball.ballObeject->getPositionY() + ball.speedY);
                
                auto objpoint = ball.ballObeject->getPosition();
                
                if(objpoint.x < widthLeft + ball.radius/2 ||
                   objpoint.x > widthRight - ball.radius/2){
                    ball.speedX *= -1;
                }
                
                if(objpoint.y < heightDown + ball.radius/2 ||
                   objpoint.y > heightUp - ball.radius/2){
                    ball.speedY *= -1;
                }
                
            }
        }

        
    };

    
    schedule(ref,"moveball");
    
    return true;
}

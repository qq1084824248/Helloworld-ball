//
//  ball.cpp
//  ShengJi
//
//  Created by duole on 2020/12/14.
//

#include "Ball.hpp"

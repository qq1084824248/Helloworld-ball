//
//  ball.hpp
//  ShengJi
//
//  Created by duole on 2020/12/14.
//

#ifndef ball_hpp
#define ball_hpp

#include <stdio.h>
#include <cocos2d.h>

struct Ball{
public:
    Ball(cocos2d::DrawNode *ballpoint,int x,int y,int r):ballObeject(ballpoint),speedX(x),speedY(y),radius(r){
        
    }
    cocos2d::DrawNode *ballObeject;
    int speedX,speedY;
    int radius;
};

#endif /* ball_hpp */

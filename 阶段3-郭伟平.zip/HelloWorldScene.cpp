#include "HelloWorldScene.h"
#include "time.h"
#include "stdlib.h"
#include "cocos-ext.h"

USING_NS_CC_EXT;
USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
bool detectCollision(HFBall& a,HFBall& b);
bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    
    //初始化边界
    auto visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();
    widthLeft = origin.x;
    widthRight = origin.x + visibleSize.width;
    heightDown = origin.y;
    heightUp = origin.y + visibleSize.height;
    
    
    //绘制清除按钮
    auto button =  cocos2d::ui::Button::create();
    button->setTitleText("Clear Button");
    button->setTitleFontSize(25);
    button->setTitleColor(Color3B::ORANGE);
    button->setPosition(Vec2(visibleSize.width/4,visibleSize.height/4));
    button->addTouchEventListener([&](Ref* sender, cocos2d::ui::Widget::TouchEventType type){
        switch (type)
        {
            case ui::Widget::TouchEventType::BEGAN:
                for(auto ball : balllist)
                {
                    this->removeChild(ball.ballObeject);
                }
                balllist.clear();
                break;
            case ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
        }
    });
    this->addChild(button, 200);
    
    
    
    
    //监听鼠标点击
    auto listener1 = EventListenerTouchOneByOne::create();
    listener1->onTouchBegan = [&](Touch* touch, Event* event)
    {
        //设定小球的属性，随机生成半径和速度
        const unsigned int x = touch->getLocation().x,y = touch->getLocation().y;
        const int radius = random(20, 50);
        const int speedX = random(-10, 10),speedY = random(-10,10);
        
        //构建小球对象，加入scene的子节点中
        DrawNode* tempball = DrawNode::create();
        tempball->drawDot(Vec2(0,0), radius, Color4F(1.0f,1.0f,1.0f,1.0f));
        tempball->setPosition(Vec2(x,y));
        this->addChild(tempball);
        
        //构建结构体，加入vector
        HFBall b(tempball,speedX,speedY,radius);
        this->balllist.push_back(b);
        
        return true;
    };
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener1, this);
    
    
    //调度器，每帧绘制
    auto ref = [&](float dt) {
        if (!balllist.empty())
        {
            //设定位置
            for (auto& ball : balllist)
            {
                ball.ballObeject->setPosition(ball.ballObeject->getPositionX() + ball.speedX,
                                              ball.ballObeject->getPositionY() + ball.speedY);
            }
            
            //判断边界条件，碰撞时速度取反
            for (auto& ball : balllist)
            {
                auto objpoint = ball.ballObeject->getPosition();
                if (objpoint.x < widthLeft + ball.radius/2)
                {
                    ball.speedX = abs(ball.speedX);
                }
                else if (objpoint.x > widthRight - ball.radius/2)
                {
                    ball.speedX = abs(ball.speedX) * -1;
                }
                
                if (objpoint.y < heightDown + ball.radius/2)
                {
                    ball.speedY = abs(ball.speedY);
                }
                else if (objpoint.y > heightUp - ball.radius/2)
                {
                    ball.speedY = abs(ball.speedY) * -1;
                }
            }
            
            //检测小球碰撞
            for (std::vector<HFBall>::iterator iter1 = balllist.begin(); iter1 != balllist.end(); ++iter1)
            {
                for (std::vector<HFBall>::iterator iter2 = iter1 + 1; iter2 != balllist.end(); ++iter2){
                    detectCollision(*iter1, *iter2);
                }
                
            }
            

        }
    };
    schedule(ref,"moveball");
    
    return true;
}

//检测小球碰撞的实际函数
bool detectCollision(HFBall& a,HFBall& b)
{
    int ballax = a.ballObeject->getPositionX();
    int ballay = a.ballObeject->getPositionY();
    int ballbx = b.ballObeject->getPositionX();
    int ballby = b.ballObeject->getPositionY();
    
    //没有碰撞，返回false
    if ((ballax-ballbx)*(ballax-ballbx) + (ballay-ballby)*(ballay-ballby)
       > (a.radius+b.radius)*(a.radius+b.radius))
    {
        return false;
    }
    //发生了碰撞
    else{
        
        if (ballax - ballbx == 0)
        {
            int tmp = a.speedY;
            a.speedY = b.speedY;
            b.speedY = tmp;
        }
        else if (ballay - ballby == 0)
        {
            int tmp = a.speedX;
            a.speedX = b.speedX;
            b.speedX = tmp;
        }
//        else if ((a.speedY/a.speedX == b.speedY/b.speedX*-1)
//           && (abs(a.speedY/a.speedX) == abs((ballay-ballby)/(ballax-ballbx))))
//        {
//            int tmp = a.speedX;
//            a.speedX = b.speedX;
//            b.speedX = tmp;
//
//            tmp = a.speedY;
//            a.speedY = b.speedY;
//            b.speedY = tmp;
//        }
        else{
            int tmp = a.speedX;
            a.speedX = b.speedX;
            b.speedX = tmp;
            
            tmp = a.speedY;
            a.speedY = b.speedY;
            b.speedY = tmp;

        }
        
        return true;
    }
    
}


#include "HelloWorldScene.h"
#include "time.h"
#include "stdlib.h"
#include "cocos-ext.h"

USING_NS_CC_EXT;
USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
bool detectCollision(HFBall& a,HFBall& b);





bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    
    //初始化边界
    auto visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();
    widthLeft = origin.x;
    widthRight = origin.x + visibleSize.width;
    heightDown = origin.y;
    heightUp = origin.y + visibleSize.height;
    
    
    //绘制清除按钮
    auto button =  cocos2d::ui::Button::create();
    button->setTitleText("Clear Button");
    button->setTitleFontSize(25);
    button->setTitleColor(Color3B::ORANGE);
    button->setPosition(Vec2(visibleSize.width/4,visibleSize.height/4));
    button->addTouchEventListener([&](Ref* sender, cocos2d::ui::Widget::TouchEventType type){
        switch (type)
        {
            case ui::Widget::TouchEventType::BEGAN:
                for(auto ball : balllist)
                {
                    this->removeChild(ball.ballObeject);
                }
                balllist.clear();
                break;
            case ui::Widget::TouchEventType::ENDED:
                break;
            default:
                break;
        }
    });
    this->addChild(button, 200);
    
    
    
    //监听鼠标点击
    auto listener1 = EventListenerTouchOneByOne::create();
    listener1->onTouchBegan = [&](Touch* touch, Event* event)
    {
        //设定小球的属性，随机生成半径和速度
        const unsigned int x = touch->getLocation().x,y = touch->getLocation().y;
        const int radius = random(20, 50);
        const int speedX = random(-10, 10),speedY = random(-10,10);
        
        //构建小球对象，加入scene的子节点中
        DrawNode* tempball = DrawNode::create();
        tempball->drawDot(Vec2(0,0), radius, Color4F(1.0f,1.0f,1.0f,1.0f));
        tempball->setPosition(Vec2(x,y));
        this->addChild(tempball);
        
        //构建结构体，加入vector
        HFBall b(tempball,speedX,speedY,radius);
        this->balllist.push_back(b);
        
        return true;
    };
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener1, this);
    
    
    //调度器，每帧绘制
    auto ref = [&](float dt) {
        if (!balllist.empty())
        {
            //设定位置
            for (auto& ball : balllist)
            {
                ball.ballObeject->setPosition(ball.ballObeject->getPositionX() + ball.speedX,
                                              ball.ballObeject->getPositionY() + ball.speedY);
            }
            
            //判断边界条件，碰撞时速度取反
            for (auto& ball : balllist)
            {
                detectboundary(ball);
            }
            
            //检测小球碰撞
            for (std::vector<HFBall>::iterator iter1 = balllist.begin(); iter1 != balllist.end(); ++iter1)
            {
                for (std::vector<HFBall>::iterator iter2 = iter1 + 1; iter2 != balllist.end(); ++iter2){
                    detectCollision(*iter1, *iter2);
                }
                
            }
            

        }
    };
    schedule(ref,"moveball");
    
    return true;
}


//平方辅助内联函数
inline int square(int x)
{
    return x*x;
}

//检测小球碰撞
bool detectCollision(HFBall& a,HFBall& b)
{
    int ballax = a.ballObeject->getPositionX();
    int ballay = a.ballObeject->getPositionY();
    int ballbx = b.ballObeject->getPositionX();
    int ballby = b.ballObeject->getPositionY();
    //没有碰撞，返回false
    if (square(ballax-ballbx) + square(ballay-ballby)
       > square(a.radius+b.radius))
    {
        return false;
    }
    //发生了碰撞
    else
    {
        //非对心碰撞
        if (ballax - ballbx == 0)
        {
            int tmp = a.speedY;
            a.speedY = b.speedY;
            b.speedY = tmp;
        }
        else if (ballay - ballby == 0)
        {
            int tmp = a.speedX;
            a.speedX = b.speedX;
            b.speedX = tmp;
        }
        //非对心碰撞的复杂情况
//        else if ((a.speedY/a.speedX == b.speedY/b.speedX*-1)
//           && (abs(a.speedY/a.speedX) == abs((ballay-ballby)/(ballax-ballbx))))
//        {
//            int tmp = a.speedX;
//            a.speedX = b.speedX;
//            b.speedX = tmp;
//
//            tmp = a.speedY;
//            a.speedY = b.speedY;
//            b.speedY = tmp;
//        }
        //对心碰撞
        else
        {
            int tmp = a.speedX;
            a.speedX = b.speedX;
            b.speedX = tmp;
            
            tmp = a.speedY;
            a.speedY = b.speedY;
            b.speedY = tmp;

        }
        
        //重新设定位置，防止小球重合
        if (square(ballax-ballbx) + square(ballay-ballby)
            < square(a.radius+b.radius))
        {
            double distance = sqrt(square(ballax-ballbx) + square(ballay-ballby));
            double overlap = (a.radius + b.radius - distance)/2;
            double speeda = sqrt(square(a.speedX) + square(a.speedY));
            double speedb = sqrt(square(b.speedX) + square(b.speedY));
            
            a.ballObeject->setPosition(a.ballObeject->getPositionX() + overlap*a.speedX/speeda,
                                       a.ballObeject->getPositionY() + overlap*a.speedY/speeda);
            b.ballObeject->setPosition(b.ballObeject->getPositionX() + overlap*b.speedX/speedb,
                                       b.ballObeject->getPositionY() + overlap*b.speedY/speedb);
        }
        return true;
    }
    
}

//检测边界碰撞
bool HelloWorld::detectboundary(HFBall &ball) {
    auto ballPosition = ball.ballObeject->getPosition();
    int state = false;
    double distancex = 0;
    double distancey = 0;
    if (ballPosition.x < widthLeft + ball.radius)
    {
        ball.speedX = abs(ball.speedX);
        state = true;
        distancex = abs(ball.radius - abs(widthLeft - ballPosition.x));
        
        ball.ballObeject->setPosition(ball.ballObeject->getPositionX() + distancex,
                                      ball.ballObeject->getPositionY() + distancex*ball.speedY/abs(ball.speedX));
    }
    else if (ballPosition.x > widthRight - ball.radius)
    {
        ball.speedX = abs(ball.speedX) * -1;
        state = true;
        distancex = abs(ball.radius - abs(widthRight - ballPosition.x));
        
        
        ball.ballObeject->setPosition(ball.ballObeject->getPositionX() - distancex,
                                      ball.ballObeject->getPositionY() + distancex*ball.speedY/abs(ball.speedX));
    }
    
    if (ballPosition.y < heightDown + ball.radius)
    {
        ball.speedY = abs(ball.speedY);
        state = true;
        distancey = abs(ball.radius - abs(heightDown - ballPosition.y));
        
        ball.ballObeject->setPosition(ball.ballObeject->getPositionX() + distancey*ball.speedX/abs(ball.speedY),
                                      ball.ballObeject->getPositionY() + distancey);
    }
    else if (ballPosition.y > heightUp - ball.radius)
    {
        ball.speedY = abs(ball.speedY) * -1;
        state = true;
        distancey = abs(ball.radius - abs(heightUp - ballPosition.y));
        
        ball.ballObeject->setPosition(ball.ballObeject->getPositionX() + distancey*ball.speedX/abs(ball.speedY),
                                      ball.ballObeject->getPositionY() - distancey);
    }
    
    return state;
    
}
